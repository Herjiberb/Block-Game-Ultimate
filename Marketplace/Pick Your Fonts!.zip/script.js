(() => {

  if (window.__FONT_PARTY_ACTIVE) {
    console.warn("Font Party already running.");
    return;
  }
  window.__FONT_PARTY_ACTIVE = true;

  const fonts = [
    "Average","Abril Fatface","Inter","Roboto","Open Sans","Lato","Montserrat","Poppins",
    "Oswald","Raleway","Nunito","Merriweather","Playfair Display","Ubuntu","Source Sans 3",
    "Fira Sans","Work Sans","Manrope","DM Sans","Quicksand","Rubik","Inconsolata",
    "Space Grotesk","Karla","Mulish","Bebas Neue","Anton","Arvo","Cabin","Catamaran",
    "Cormorant Garamond","Crimson Text","Exo 2","Hind","IBM Plex Sans","IBM Plex Serif",
    "Josefin Sans","Libre Baskerville","Libre Franklin","Lobster","M PLUS Rounded 1c",
    "Nanum Gothic","Noto Sans","Noto Serif","Overpass","PT Sans","PT Serif","Questrial",
    "Red Hat Display","Saira","Signika","Titillium Web","Varela Round","Yantramanav",
    "Zilla Slab","Barlow","Barlow Condensed","Bitter","Chivo","Dosis","Eczar","Heebo",
    "Kanit","Lexend","Martel","Maven Pro","Neuton","Prompt","Public Sans","Recursive",
    "Sarabun","Spectral","Tajawal","Urbanist","Assistant","Bricolage Grotesque",
    "Archivo","Archivo Narrow","Atkinson Hyperlegible","Alegreya","Alegreya Sans",
    "Baloo 2","Belleza","Cairo","Comfortaa","Didact Gothic","Domine","Encode Sans",
    "Frank Ruhl Libre","Glegoo","Hammersmith One","Itim","Jost"
  ].slice(0,100);

  function buildURL(list){
    return "https://fonts.googleapis.com/css2?"
      + list.map(f =>
          `family=${encodeURIComponent(f).replace(/%20/g,"+")}:wght@300;400;500;600;700;800`
        ).join("&")
      + "&display=swap";
  }

  // Load fonts once
  let link = document.getElementById("__font-party-link");
  if(!link){
    link = document.createElement("link");
    link.id = "__font-party-link";
    link.rel = "stylesheet";
    link.href = buildURL(fonts);
    document.head.appendChild(link);
  }

  // Persistent style (NOT removed when panel closes)
  let style = document.getElementById("__font-party-style");
  if(!style){
    style = document.createElement("style");
    style.id = "__font-party-style";
    style.textContent = `
      :root{
        --__font-party-font: "Average";
      }

      html, body, body *{
        font-family: var(--__font-party-font), system-ui, -apple-system, Segoe UI, sans-serif !important;
      }
    `;
    document.head.appendChild(style);
  }

  // UI panel only
  const panel = document.createElement("div");
  Object.assign(panel.style,{
    position:"fixed",
    bottom:"18px",
    right:"18px",
    zIndex:2147483647,
    background:"linear-gradient(180deg,#ffffff,#f4fbff)",
    borderRadius:"14px",
    boxShadow:"0 12px 30px rgba(0,0,0,.25)",
    padding:"12px 14px",
    fontFamily:"system-ui, sans-serif",
    minWidth:"260px"
  });

  const title = document.createElement("div");
  title.textContent = "🎨 Font Party";
  title.style.fontWeight = "700";
  title.style.marginBottom = "6px";

  const select = document.createElement("select");
  Object.assign(select.style,{
    width:"100%",
    padding:"8px",
    borderRadius:"8px",
    border:"1px solid #cfe6f3",
    fontSize:"14px"
  });

  fonts.forEach(f=>{
    const o = document.createElement("option");
    o.value = f;
    o.textContent = f;
    select.appendChild(o);
  });

  // Keep previous font if already set
  const current =
    getComputedStyle(document.documentElement)
      .getPropertyValue("--__font-party-font")
      .replace(/["']/g,"")
      .trim();

  select.value = fonts.includes(current) ? current : "Average";

  const close = document.createElement("button");
  close.textContent = "✕";
  Object.assign(close.style,{
    position:"absolute",
    top:"6px",
    right:"8px",
    border:"none",
    background:"transparent",
    cursor:"pointer",
    fontSize:"16px"
  });

  panel.appendChild(title);
  panel.appendChild(select);
  panel.appendChild(close);
  document.body.appendChild(panel);

  function applyFont(name){
    document.documentElement
      .style
      .setProperty("--__font-party-font", `"${name}"`);
  }

  applyFont(select.value);

  select.addEventListener("change",()=>{
    applyFont(select.value);
  });

  // 🔒 Stop game keys (WASD etc) from leaking while using the menu
  ["keydown","keyup","keypress"].forEach(type=>{
    panel.addEventListener(type, e=>{
      e.stopPropagation();
    }, true);
  });

  // Also stop wheel/drag leaking through the panel
  ["wheel","mousedown","mouseup","pointerdown","pointerup","touchstart"].forEach(type=>{
    panel.addEventListener(type, e=>{
      e.stopPropagation();
    }, true);
  });

  // Close ONLY the panel – keep fonts
  close.onclick = () => {
    try{ panel.remove(); }catch(e){}
    window.__FONT_PARTY_ACTIVE = false;
  };

  // Optional full cleanup if you really want to revert fonts
  window.__FONT_PARTY_RESET = () => {
    try{ panel.remove(); }catch(e){}
    try{ style.remove(); }catch(e){}
    window.__FONT_PARTY_ACTIVE = false;
    console.log("Font Party fully removed and fonts restored.");
  };

  console.log(
    "Font Party fixed. Closing panel keeps the font. Use __FONT_PARTY_RESET() to revert."
  );

})();
