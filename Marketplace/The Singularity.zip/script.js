(function() {
    // Prevent duplicate injection logic, but allow multiple black hole instances
    if (window.singularityInjectionActive) {
        addToInventory('singularity_cannon', 1);
        return;
    }
    window.singularityInjectionActive = true;

    // --- 1. ASSET GENERATION ---
    const iconCanvas = document.createElement('canvas');
    iconCanvas.width = 32; iconCanvas.height = 32;
    const ictx = iconCanvas.getContext('2d');
    ictx.fillStyle = "#000";
    ictx.beginPath(); ictx.arc(16, 16, 12, 0, Math.PI*2); ictx.fill();
    ictx.strokeStyle = "#ff00ff";
    ictx.lineWidth = 2;
    ictx.stroke();
    const gunIconUrl = iconCanvas.toDataURL();
    const gunImg = new Image();
    gunImg.src = gunIconUrl;
    assets['singularity_cannon'] = gunImg;

    // --- 2. REGISTER ITEM ---
    itemTypes['singularity_cannon'] = {
        imgSrc: 'generated',
        color: '#4b0082',
        isTool: true,
        isGun: true,
        gunPower: 0,
        fireRate: 1.5,
        maxDurability: 9999,
        rarity: 'void' 
    };

    // --- 3. THE INFINITE SINGULARITY CLASS ---
    class EternalSingularity {
        constructor(x, y) {
            this.x = x;
            this.y = y;
            this.radius = 10;
            this.growthFactor = 0.02; // Grows slightly every frame
            this.colorHue = 280; // Start with purple
            this.mass = 1; // Used for gravity scaling
        }

        update() {
            // 1. CONSTANT GROWTH
            this.radius += this.growthFactor;
            this.mass = this.radius / 10;
            this.colorHue = (this.colorHue + 0.5) % 360;

            const pullRadius = this.radius * 8;
            const ripRange = this.radius * 1.5;

            // 2. EXTREME CAMERA SHAKE (Scales with size)
            const distToPlayer = Math.sqrt(Math.pow(this.x - (player.x + playerWidth/2), 2) + Math.pow(this.y - (player.y + playerHeight/2), 2));
            if (distToPlayer < pullRadius * 2) {
                const intensity = (this.radius / 20) * (1 - distToPlayer / (pullRadius * 2));
                camera.x += (Math.random() - 0.5) * intensity;
                camera.y += (Math.random() - 0.5) * intensity;
            }

            // 3. PHYSICAL PULL (Entities, Drops, Bees)
            const targets = [...animatedDrops, ...bees, ...bullets];
            targets.forEach(t => {
                const dx = this.x - t.x;
                const dy = this.y - t.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                
                if (dist < pullRadius) {
                    const force = (this.mass * 10) / (dist / 10);
                    t.dx += (dx / dist) * force;
                    t.dy += (dy / dist) * force;
                    // Orbiting effect
                    t.dx += -(dy / dist) * (this.mass * 0.2);
                    t.dy += (dx / dist) * (this.mass * 0.2);
                }
                
                if (dist < this.radius) {
                    if (t.life !== undefined) t.life = 0;
                    if (t.pickupDelay !== undefined) t.x = -9999; // Delete drops
                    this.radius += 0.01; // Eating things makes it grow faster!
                }
            });

            // 4. BLOCK CONSUMPTION (The "Sucking" effect)
            const rangeInTiles = Math.ceil(ripRange / tileSize);
            const centerCol = Math.floor(this.x / tileSize);
            const centerRow = Math.floor(this.y / tileSize);

            for (let i = 0; i < 5 + Math.floor(this.radius/10); i++) {
                const rCol = centerCol + Math.floor((Math.random() - 0.5) * 2 * rangeInTiles);
                const rRow = centerRow + Math.floor((Math.random() - 0.5) * 2 * rangeInTiles);
                const key = `${rCol},${rRow}`;
                
                if (worldBlocks[key] && worldBlocks[key].type !== '' && worldBlocks[key].type !== 'bedrock_stone') {
                    const bX = rCol * tileSize;
                    const bY = rRow * tileSize;
                    const dX = this.x - bX;
                    const dY = this.y - bY;
                    const dist = Math.sqrt(dX*dX + dY*dY);

                    if (dist < ripRange) {
                        // Spawn block particles that get sucked in
                        const type = worldBlocks[key].type;
                        createBlockBreakParticles(rCol, rRow, type);
                        
                        // Tag recent particles to fly toward center
                        const startIdx = particles.length - 5;
                        for(let p = Math.max(0, startIdx); p < particles.length; p++) {
                            particles[p].isSucked = true;
                            particles[p].targetX = this.x;
                            particles[p].targetY = this.y;
                        }

                        worldBlocks[key] = { type: '', mineProg: 0 };
                        this.radius += 0.05; // Each block feeds the void
                    }
                }
            }
        }

        draw() {
            const sx = this.x - camera.x;
            const sy = this.y - camera.y;

            ctx.save();
            ctx.translate(sx, sy);
            
            // Outer accretion disk
            const grad = ctx.createRadialGradient(0, 0, this.radius * 0.5, 0, 0, this.radius * 2.5);
            grad.addColorStop(0, 'black');
            grad.addColorStop(0.2, `hsla(${this.colorHue}, 100%, 50%, 0.8)`);
            grad.addColorStop(0.5, `hsla(${(this.colorHue + 40)%360}, 100%, 30%, 0.4)`);
            grad.addColorStop(1, 'transparent');

            ctx.rotate(gameTime * 0.002);
            ctx.fillStyle = grad;
            ctx.scale(1.5, 0.8); // Flatten it like a real galaxy
            ctx.beginPath();
            ctx.arc(0, 0, this.radius * 2.5, 0, Math.PI*2);
            ctx.fill();
            
            ctx.restore();

            // The Event Horizon (The Pure Black Hole)
            ctx.beginPath();
            ctx.arc(sx, sy, this.radius, 0, Math.PI*2);
            ctx.fillStyle = 'black';
            ctx.fill();
            ctx.strokeStyle = 'white';
            ctx.lineWidth = Math.max(1, this.radius / 20);
            ctx.stroke();
        }
    }

    // --- 4. ENGINE OVERRIDES ---
    window.eternalVoids = [];

    const oldUpdate = window.update;
    window.update = function(dt) {
        oldUpdate(dt);
        window.eternalVoids.forEach(v => v.update());
    };

    const oldDraw = window.draw;
    window.draw = function() {
        oldDraw();
        window.eternalVoids.forEach(v => v.draw());
    };

    // Particle sucking logic
    const oldPartUpdate = window.updateParticles;
    window.updateParticles = function(dt) {
        for (let i = particles.length - 1; i >= 0; i--) {
            const p = particles[i];
            if (p.isSucked) {
                const dx = p.targetX - p.x;
                const dy = p.targetY - p.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist < 5) {
                    particles.splice(i, 1);
                    continue;
                }
                p.dx += (dx/dist) * 2;
                p.dy += (dy/dist) * 2;
                p.x += p.dx; p.y += p.dy;
                p.dx *= 0.8; p.dy *= 0.8;
            }
        }
        oldPartUpdate(dt);
    };

    const oldShoot = window.handleShooting;
    window.handleShooting = function(dt) {
        const item = getSelectedItem();
        if (item && item.type === 'singularity_cannon') {
            if (mouse.down && gunCooldown <= 0) {
                gunCooldown = 1000;
                const wx = mouse.x + camera.x;
                const wy = mouse.y + camera.y;
                window.eternalVoids.push(new EternalSingularity(wx, wy));
                
                // Recoil
                const angle = Math.atan2(wy - (player.y + playerHeight/2), wx - (player.x + playerWidth/2));
                player.dx -= Math.cos(angle) * 15;
                player.dy -= Math.sin(angle) * 15;
                
                showMessageBox("THE VOID EXPANDS", "info");
            }
            return;
        }
        oldShoot(dt);
    };

    addToInventory('singularity_cannon', 1);
    console.log("Eternal Singularity Protocol Engaged.");
    showMessageBox("ETERNAL SINGULARITY LOADED.\n\nThey never stop growing.\nThey never stop eating.\nFire multiple to end the world.", "alert");
})();