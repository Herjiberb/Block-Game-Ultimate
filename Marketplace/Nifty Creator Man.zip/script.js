// --- NIFTY CREATOR MAN (v3 - Registry Injection Edition) ---
let niftyCreatorEnabled = false;

// The Console Command to activate
window.niftyCreatorMan = function() {
    niftyCreatorEnabled = true;
    const msg = "Nifty Creator Man v3 ACTIVATED!\n1. Hover over an Item Frame.\n2. Press 'Y' to upload art.\n3. Breaking custom art now drops Item Frames!";
    console.log("%c" + msg, "color: #00BFFF; font-weight: bold; font-size: 14px;");
    return "Ready.";
};

// Hidden File Input
const niftyInput = document.createElement('input');
niftyInput.type = 'file';
niftyInput.accept = 'image/*';
niftyInput.style.display = 'none';
document.body.appendChild(niftyInput);

let niftyTargetCol = 0;
let niftyTargetRow = 0;

// NEW: Keyboard listener for 'y'
window.addEventListener('keydown', (e) => {
    if (niftyCreatorEnabled && e.key.toLowerCase() === 'y' && !isConsoleOpen && !isGamePaused) {
        const hoverCol = Math.floor((mouse.x + camera.x) / tileSize);
        const hoverRow = Math.floor((mouse.y + camera.y) / tileSize);
        
        if (getBlockType(hoverCol, hoverRow) === 'item_frame') {
            niftyTargetCol = hoverCol;
            niftyTargetRow = hoverRow;
            niftyInput.value = '';
            niftyInput.click();
        }
    }
});

niftyInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Detect max rectangle of item frames starting from hover point
    let maxWidth = 0;
    while (getBlockType(niftyTargetCol + maxWidth, niftyTargetRow) === 'item_frame') {
        maxWidth++;
    }

    let maxHeight = 0;
    while (getBlockType(niftyTargetCol, niftyTargetRow + maxHeight) === 'item_frame') {
        maxHeight++;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
            // Ask for grid size based on what we found
            let buttonsHtml = '';
            for (let w = 1; w <= maxWidth; w++) {
                for (let h = 1; h <= maxHeight; h++) {
                    if (w === h || (w <= 8 && h <= 8)) { // Keep UI sane
                        buttonsHtml += `<button onclick="applyNiftyGrid(${w}, ${h}, '${event.target.result}')" style="margin:4px; padding:8px; background:#28a745; color:white; border:none; border-radius:4px; cursor:pointer;">${w}x${h}</button>`;
                    }
                }
            }

            const modal = document.createElement('div');
            modal.id = "niftyModal";
            modal.innerHTML = `<div style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.8);z-index:10000;display:flex;flex-direction:column;justify-content:center;align-items:center;color:white;font-family:sans-serif;">
                <h2 style="color:#00BFFF">Select Mural Size</h2>
                <div style="display:flex; flex-wrap:wrap; justify-content:center; max-width:400px;">${buttonsHtml}</div>
                <button onclick="document.getElementById('niftyModal').remove()" style="margin-top:15px; background:#dc3545; color:white; border:none; padding:10px 20px; border-radius:5px; cursor:pointer;">Cancel</button>
            </div>`;
            
            window.applyNiftyGrid = (w, h, src) => {
                modal.remove();
                createCodedBlocks(img, w, h);
            };
            document.body.appendChild(modal);
        };
        img.src = event.target.result;
    };
    reader.readAsDataURL(file);
});

function createCodedBlocks(img, gridW, gridH) {
    const sliceW = img.width / gridW;
    const sliceH = img.height / gridH;
    const batchID = Date.now(); // Unique ID for this specific image

    for (let x = 0; x < gridW; x++) {
        for (let y = 0; y < gridH; y++) {
            const canvas = document.createElement('canvas');
            canvas.width = sliceW;
            canvas.height = sliceH;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, x * sliceW, y * sliceH, sliceW, sliceH, 0, 0, sliceW, sliceH);
            
            const dataUrl = canvas.toDataURL('image/png');
            const blockID = `nifty_${batchID}_${x}_${y}`;

            // 1. INJECT into blockTypes Registry
            // This makes the game treat it like a real block (stone, dirt, etc)
            blockTypes[blockID] = {
                imgSrc: dataUrl,
                solid: true,
                miningHardness: 50, // Same as wood/item frames
                // THE KEY: When broken, it drops a standard item_frame
                drops: [{item: 'item_frame', chance: 1, min: 1, max: 1}],
                color: '#444',
                breakSound: ['plank_break_1', 'plank_break_2']
            };

            // 2. REPLACE the block in the world
            const worldKey = `${niftyTargetCol + x},${niftyTargetRow + y}`;
            worldBlocks[worldKey] = {
                type: blockID,
                mineProg: 0
            };
        }
    }
    console.log(`Success: Created ${gridW * gridH} custom coded blocks.`);
}
// --- RENDERER PATCH FOR CUSTOM BLOCKS ---
const originalDrawWorld = window.drawWorld;

window.drawWorld = function() {
    // We are wrapping the original drawWorld to handle custom textures
    // But since drawWorld is likely a large loop, it's more efficient to 
    // ensure our custom blocks have their images ready in the 'assets' cache.
    
    for (let key in worldBlocks) {
        let block = worldBlocks[key];
        if (block.type.startsWith('nifty_')) {
            let typeData = blockTypes[block.type];
            
            // If the image isn't in the game's asset cache yet, put it there
            if (typeData && typeData.imgSrc && !assets[block.type]) {
                const img = new Image();
                img.src = typeData.imgSrc;
                assets[block.type] = img; // Inject into the game's main asset registry
            }
        }
    }
    
    // Now call the original draw function - it will now find the images in assets[]
    originalDrawWorld();
};

console.log("Renderer patched: Custom blocks will now display images.");

niftyCreatorMan();