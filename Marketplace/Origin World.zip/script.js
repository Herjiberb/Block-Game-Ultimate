// =========================================================================
//  BGU MODDING TEMPLATE: Custom Biomes & World Gen
// =========================================================================

// 1. CONFIGURATION
// Add as many biomes as you want here.
const CUSTOM_BIOMES = [
    {
        id: "origin_plateau", // The internal ID of your biome
        weight: 100,          // Rarity (High = Common, Low = Rare). Standard forests are ~100.
        
        // The 10-block deep surface definition.
        // Index 0 is the grass/surface. Index 9 is the deepest part before stone starts.
        layers: [
            // DEPTH 0: Surface (Grass)
            {
                blocks: [ 
                    { type: "incandesoil", chance: 1.0 } 
                ],
                // Features only run on Depth 0
                features: [
                    { type: "tree", treeType: "blueglow", chance: 0.04 }, // Uses game's built-in tree types
                    { type: "foliage", blockType: "shallow_grass", chance: 0.4 }
                    // You can add complex trees here if you know the names (e.g. 'baobab', 'acacia')
                    // { type: "complexTree", treeType: "baobab", chance: 0.01 } 
                ]
            },
            // DEPTH 1: Just below surface
            {
                blocks: [ 
                    { type: "incandesoil", chance: 0.8 }, 
                    { type: "flyiensoil", chance: 0.2 } 
                ]
            },
            // DEPTH 2
            {
                blocks: [ 
                    { type: "incandesoil", chance: 0.6 }, 
                    { type: "flyiensoil", chance: 0.4 } 
                ]
            },
            // DEPTH 3
            {
                blocks: [ 
                    { type: "flyiensoil", chance: 1.0 } 
                ]
            },
            // DEPTH 4
            {
                blocks: [ 
                    { type: "flyiensoil", chance: 0.5 },
                    { type: "originstone", chance: 0.5 }
                ]
            },
            // DEPTH 5 - 8 (Deep dirt/stone mix)
            { blocks: [ { type: "originstone", chance: 1.0 } ] }, // Depth 5
            { blocks: [ { type: "originstone", chance: 1.0 } ] }, // Depth 6
            { blocks: [ { type: "originstone", chance: 1.0 } ] }, // Depth 7
            { 
                blocks: [ 
                    { type: "originstone", chance: 0.95 },
                    { type: "orichalcum_originistone", chance: 0.05 } // Rare ore layer
                ] 
            }, // Depth 8
            
            // DEPTH 9: Final layer before deep stone
            {
                blocks: [ 
                    { type: "originstone", chance: 1.0 } 
                ]
            }
        ]
    }
];

// =========================================================================
//  ENGINE INJECTION LOGIC (DO NOT EDIT UNLESS YOU KNOW WHAT YOU ARE DOING)
// =========================================================================

console.log("[MOD] Initializing Custom Biome Script...");

// 1. Capture Original Functions
const _bgu_originalGetBiome = getBiome;
const _bgu_originalGetBlockData = getBlockData;

// 2. Override getBiome to include our custom weights
// We have to completely redefine the selection logic to insert our weights cleanly.
getBiome = function(col) {
    if (worldBiomes[col]) return worldBiomes[col].type;

    // Define standard weights (approximate values based on vanilla BGU)
    let biomePool = [
        { type: 'deciduous_forest',  weight: 100 },
        { type: 'desert',            weight: 60 },
        { type: 'coniferous_forest', weight: 50 },
        { type: 'grass_field',       weight: 50 },
        { type: 'rocky',             weight: 30 },
        { type: 'rainforest',        weight: 25 },
        { type: 'taiga',             weight: 20 },
        // ... (The game usually has more, but this ensures fallback)
    ];

    // Inject Custom Biomes
    CUSTOM_BIOMES.forEach(cb => {
        biomePool.push({ type: cb.id, weight: cb.weight });
    });

    function selectNextBiome() {
        if (typeof allBiome !== 'undefined' && allBiome !== 'start') return allBiome;

        let totalWeight = 0;
        for (let i = 0; i < biomePool.length; i++) totalWeight += biomePool[i].weight;

        let randomValue = random() * totalWeight;
        for (let i = 0; i < biomePool.length; i++) {
            if (randomValue < biomePool[i].weight) {
                return biomePool[i].type;
            }
            randomValue -= biomePool[i].weight;
        }
        return biomePool[0].type;
    }

    // Generation Logic (matches vanilla direction handling)
    if (col > lastBiomeEndCol) {
        const biomeType = selectNextBiome();
        const biomeWidth = 40 + Math.floor(random() * 21);
        const biomeStartCol = lastBiomeEndCol + 1;
        const biomeEndCol = biomeStartCol + biomeWidth - 1;
        for (let i = biomeStartCol; i <= biomeEndCol; i++) {
            worldBiomes[i] = { type: biomeType, start: biomeStartCol, end: biomeEndCol };
        }
        lastBiomeEndCol = biomeEndCol;
    } else if (col < firstBiomeStartCol) {
        const biomeType = selectNextBiome();
        const biomeWidth = 40 + Math.floor(random() * 21);
        const biomeEndCol = firstBiomeStartCol - 1;
        const biomeStartCol = biomeEndCol - biomeWidth + 1;
        for (let i = biomeStartCol; i <= biomeEndCol; i++) {
            worldBiomes[i] = { type: biomeType, start: biomeStartCol, end: biomeEndCol };
        }
        firstBiomeStartCol = biomeStartCol;
    }
    
    return worldBiomes[col] ? worldBiomes[col].type : 'deciduous_forest';
};

// 3. Override getBlockData to handle specific block placement
getBlockData = function(col, row) {
    const key = `${col},${row}`;
    
    // Return cached if exists
    if (worldBlocks[key] !== undefined) return worldBlocks[key];

    // Ensure surface height exists for this column (copied logic from base game)
    if (columnSurfaceHeights[col] === undefined) {
        let prevSurface = baseSurfaceLevel + Math.floor(surfaceLevelRange / 2);
        if (columnSurfaceHeights[col - 1] !== undefined) prevSurface = columnSurfaceHeights[col - 1];
        else if (columnSurfaceHeights[col + 1] !== undefined) prevSurface = columnSurfaceHeights[col + 1];
        
        const offset = Math.floor(random() * 3) - 1;
        let potentialHeight = prevSurface + offset;
        columnSurfaceHeights[col] = Math.max(baseSurfaceLevel + minSurfaceVariation, Math.min(baseSurfaceLevel + maxSurfaceVariation, potentialHeight));
    }
    
    const surfaceHeight = columnSurfaceHeights[col];
    const biome = getBiome(col);
    
    // Check if this is one of our custom biomes
    const modBiomeConfig = CUSTOM_BIOMES.find(b => b.id === biome);

    if (modBiomeConfig) {
        // Calculate depth relative to surface
        const depth = row - surfaceHeight;

        // Handle Surface & Underground Layers (0 to 9)
        if (depth >= 0 && depth <= 9) {
            const layerConfig = modBiomeConfig.layers[depth];
            
            if (layerConfig) {
                // 1. Pick Block Type
                let selectedBlock = "";
                const roll = random(); // Use seeded random
                let currentChance = 0;
                
                // Determine block based on weights
                for (const blockOption of layerConfig.blocks) {
                    currentChance += blockOption.chance;
                    if (roll < currentChance) {
                        selectedBlock = blockOption.type;
                        break;
                    }
                }
                
                // If nothing selected (e.g. chances didn't add up to 1), pick the first one
                if (!selectedBlock && layerConfig.blocks.length > 0) {
                    selectedBlock = layerConfig.blocks[0].type;
                }

                // 2. Handle Surface Features (Depth 0 only)
                if (depth === 0 && layerConfig.features) {
                    const blockAboveKey = `${col},${row - 1}`;
                    if (worldBlocks[blockAboveKey] === undefined || worldBlocks[blockAboveKey].type === '') {
                        for (const feature of layerConfig.features) {
                            if (random() < feature.chance) {
                                if (feature.type === 'tree') {
                                    generateTree(col, row, feature.treeType);
                                } 
                                else if (feature.type === 'complexTree') {
                                    generateComplexTree(col, row, feature.treeType);
                                }
                                else if (feature.type === 'cactus') {
                                    generateCactus(col, row);
                                }
                                else if (feature.type === 'tallFoliage') {
                                    generateTallFoliage(col, row, feature.foliageType);
                                }
                                else if (feature.type === 'foliage') {
                                    worldBlocks[blockAboveKey] = { type: feature.blockType, mineProg: 0 };
                                }
                                break; // Only spawn one feature per block
                            }
                        }
                    }
                }

                // Return and Cache the block
                const newBlock = { type: selectedBlock, mineProg: 0 };
                worldBlocks[key] = newBlock;
                return newBlock;
            }
        }
    }

    // If not a custom biome or not in the 0-9 depth range, hand back to original engine
    return _bgu_originalGetBlockData(col, row);
};

console.log("[MOD] Custom Biomes Registered Successfully.");